#include <bits/stdc++.h>

typedef long long ll;
typedef unsigned long long ull;
#define FOR(i, a, b) for (int i = a; i <= b; ++i)
#define ROF(i, a, b) for (int i = a; i >= b; --i)

using namespace std;

const int N = 105;
int n, m, k;
int dp[1 << 20], a[N];
int main() {
//    freopen("candy.in", "r", stdin);
//    freopen("candy.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= k; ++j) {
            int x;
            scanf("%d", &x);
            a[i] |= (1 << (x - 1));
        }
    }
    memset(dp, 0x3f, sizeof(dp));
    dp[0] = 0;
    for (int i = 0; i < n; ++i) {
        for (int S = 0; S < (1 << m); ++S) {
            if (dp[S] == 0x3f3f3f3f) continue;
            dp[S | a[i + 1]] = min(dp[S | a[i + 1]], dp[S] + 1);
        }
    }
    if (dp[(1 << m) - 1] != 0x3f3f3f3f) {
        printf("%d\n", dp[(1 << m) - 1]);
    } else {
        puts("-1");
    }
    return 0;
}
