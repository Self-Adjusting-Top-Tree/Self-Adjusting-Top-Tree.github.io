#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

const int N = 505, inf = 0x3f3f3f3f;
int n, a[N];
ll dp[N][N], f[N][N][5], g[N][N][5];
int main() {
    freopen("zuma.in", "r", stdin);
    freopen("zuma.out", "w", stdout);
    scanf("%d", &n); 
    for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
    for (int i = 1; i <= n; ++i) {
        for (int k = 2; k <= 4; ++k) f[i][i][k] = g[i][i][k] = inf;
        if (a[i] != a[i - 1] && a[i] != a[i + 1]) {
            dp[i][i] = 2;
        } else {
            dp[i][i] = inf;
        }
    }
    for (int len = 2; len <= n; ++len) {
        for (int l = 1; l <= n - len + 1; ++l) {
            int r = l + len - 1;
            f[l][r][1] = dp[l][r - 1];
            g[l][r][1] = dp[l][r - 1];
            for (int k = 2; k <= 4; ++k) {
                ll z = inf, t = inf;
                for (int i = l; i < r; ++i) {
                    if (a[i] != a[r]) continue;
                    z = min(z, f[l][i][k - 1] + dp[i + 1][r - 1]);
                    if (k != 3 || i + 1 < r) t = min(t, g[l][i][k - 1] + dp[i + 1][r - 1]);
                }
                f[l][r][k] = z;
                g[l][r][k] = t;
            }
            ll ans = inf;
            for (int i = l; i <= r; ++i) {
                if (a[i] == a[l - 1] || a[i] == a[r + 1]) continue;
                for (int k = 1; k <= 3; ++k) {
                    ans = min(ans, f[l][i][k] + dp[i + 1][r] + 3 - k);
                }
                ans = min(ans, g[l][i][4] + dp[i + 1][r]);
            }
            dp[l][r] = ans;
        }
    }
    printf("%lld\n", dp[1][n]);
    return 0;
}
