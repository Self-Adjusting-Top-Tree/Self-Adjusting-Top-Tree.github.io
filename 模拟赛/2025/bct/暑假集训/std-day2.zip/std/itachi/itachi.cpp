#include <bits/stdc++.h>

typedef long long ll;
typedef unsigned long long ull;
#define FOR(i, a, b) for (int i = a; i <= b; ++i)
#define ROF(i, a, b) for (int i = a; i >= b; --i)
#define NEXT(i, r, v) for (int i = h[r], v; v = e[i].v, i; i = e[i].u)

int read() {
    int f = 1, x = 0;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') {
        x = (x << 1) + (x << 3) + (ch ^ 48);
        ch = getchar();
    }
    return x * f;
}

using namespace std;

const int N = 5e5 + 7, mod = 1e9 + 7;
int n, k;
ll ksm(ll a, ll b) {
    ll res = 1;
    while (b) {
        if (b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
ll inv(const ll &a) { return ksm(a, mod - 2); }
vector<int> e[N];
ll fac[N], invfac[N];
ll C(int n, int m) { return n < m ? 0 : fac[n] * invfac[m] % mod * invfac[n - m] % mod; }
void init(int n) {
    fac[0] = 1;
    FOR(i, 1, n) fac[i] = fac[i - 1] * i % mod;
    invfac[n] = inv(fac[n]);
    ROF(i, n - 1, 0) invfac[i] = invfac[i + 1] * (i + 1) % mod;
}
int sz[N];
ll sum[N], now, res;
void dfs(int u, int last) {
    sz[u] = 1;
    for (int &v : e[u]) {
        if (v == last) continue;
        dfs(v, u);
        sz[u] += sz[v];
    }
    sum[u] = C(sz[u], k);
    for (int &v : e[u]) {
        if (v != last) sum[u] = (sum[u] - C(sz[v], k) + mod) % mod;
    }
    now = (now + sum[u] * sz[u]) % mod;
}
void chg(int u, int v) {
    now = (now - sum[u] * sz[u] % mod + mod) % mod;
    now = (now - sum[v] * sz[v] % mod + mod) % mod;
    sum[u] = (sum[u] - C(sz[u], k) + C(sz[v], k) + mod) % mod;
    sum[v] = (sum[v] - C(sz[v], k) + mod) % mod;
    sz[u] -= sz[v], sz[v] += sz[u];
    sum[u] = (sum[u] + C(sz[u], k)) % mod;
    sum[v] = (sum[v] + C(sz[v], k) - C(sz[u], k) + mod) % mod;
    now = (now + sum[u] * sz[u]) % mod;
    now = (now + sum[v] * sz[v]) % mod;
}
void Dfs(int u, int last) {
    res = (res + now) % mod;
    for (int &v : e[u]) {
        if (v == last) continue;
        chg(u, v);
        Dfs(v, u);
        chg(v, u);
    }
}
int main() {
    freopen("itachi.in", "r", stdin);
    freopen("itachi.out", "w", stdout);
    scanf("%d%d", &n, &k);
    FOR(i, 1, n - 1) {
        int u, v;
        scanf("%d%d", &u, &v);
        e[u].push_back(v), e[v].push_back(u);
    }
    init(n);
    dfs(1, 0);
    Dfs(1, 0);
    printf("%lld\n", res);
    return 0;
}