#include <bits/stdc++.h>

typedef long long ll;
typedef unsigned long long ull;
#define FOR(i, a, b) for (int i = a; i <= b; ++i)
#define ROF(i, a, b) for (int i = a; i >= b; --i)

using namespace std;

const int N = 5005, mod = 998244353;

int n, m, c;
ll f[N][2];
int main() {
    freopen("deidara.in", "r", stdin);
    freopen("deidara.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &c);
    f[0][1] = 1;
    FOR(z, 0, c - 1) {
        for (int x = z; x <= n; x += c) {
            if (x == 0) continue;
            if (x == n) {
                ROF(i, m, 0) {
                    f[i][1] = ((i > 0 ? f[i - 1][1] : 0) + f[i][0]) % mod;
                    f[i][0] = 0;
                }
            } else {
                ROF(i, m, 0) {
                    ll t = f[i][1];
                    f[i][1] = ((i > 0 ? f[i - 1][1] : 0) + f[i][0]) % mod;
                    f[i][0] = (f[i][0] + t) % mod;
                }
            }
        }
        FOR(i, 0, m) {
            f[i][0] = (f[i][0] + f[i][1]) % mod;
            f[i][1] = 0;
        }
    }
    FOR(i, 0, m) { printf("%lld ", f[i][0]); }
    puts("");
    return 0;
}